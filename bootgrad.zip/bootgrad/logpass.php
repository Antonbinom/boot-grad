<?php
$mail->Username   = ''; // Логин на google почте
$mail->Password   = ''; // Пароль на google почте